﻿namespace EmployeeManagement.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Prename { get; set; }
        public string Lastname { get; set; }
    }
}
